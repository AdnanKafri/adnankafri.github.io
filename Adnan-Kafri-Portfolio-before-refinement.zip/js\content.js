/* Edit all English/Arabic copy here. Set project image/live/github to real paths
   and URLs when available; null values intentionally display placeholders. */
window.PORTFOLIO = {
  projects: [
    { image: null, live: null, github: null, stack: ['Laravel','FastAPI','TailwindCSS','MySQL','EfficientNet-B4','BiLSTM','MFCC'] },
    { image: null, live: null, github: null, stack: ['Laravel','MySQL','Flutter','Generative AI API'] },
    { image: null, live: null, github: null, stack: ['Laravel','MySQL','REST API'] }
  ],
  en: {
    metaTitle: 'Adnan Kafri — Laravel Backend Developer & AI Systems', metaDescription: 'Adnan Kafri, backend-focused Computer Engineer in Hama, Syria. Laravel, REST APIs, relational databases and AI-integrated web platforms. Available for remote freelance work.',
    skip: 'Skip to content', name: 'Adnan Kafri', intro: 'COMPUTER ENGINEER · BACKEND DEVELOPER',
    title: 'Backend Web Developer (Laravel) | AI-Integrated Systems',
    statement: 'Thoughtful backends.\nIntelligent possibilities.',
    value: 'I build Laravel platforms, reliable REST APIs, and web experiences that bring AI into practical use.',
    available: 'Available for freelance work', viewProjects: 'View projects', contactMe: 'Contact me', location: 'Hama, Syria',
    portraitLabel: 'Engineering meets applied AI.', portraitNote: 'Built on solid foundations.', portraitSub: 'Laravel · APIs · Applied AI', portraitAlt: 'Adnan Kafri speaking into a microphone', aiSystems: 'AI-integrated systems',
    nav: [['about','About'],['skills','Skills'],['experience','Experience'],['projects','Projects'],['contact','Let’s talk ↗']],
    aboutLabel: '01 / A LITTLE CONTEXT', aboutTitle: 'The engineer behind the code.',
    profile: 'I’m a backend-focused Computer Engineer with 3+ years of hands-on Laravel development. I specialize in REST APIs, relational databases, and production deployments, and integrate deep learning models and LLM-powered features into web platforms. A graduate with distinction, I also bring a research perspective through my published work on deepfake detection.',
    facts: [['Based in','Hama, Syria · Working remotely'],['Languages','Arabic — Native · English — C1'],['Education','B.Sc. Computer Engineering · Graduated with distinction']],
    skillsLabel: '02 / THE TOOLKIT', skillsTitle: 'The right tools. A solid foundation.',
    skills: [
      ['Backend & Web',['Laravel','PHP','CodeIgniter','FastAPI (Python)','REST API Design','HTML','CSS','JavaScript','Bootstrap','TailwindCSS']],
      ['AI & Machine Learning',['Deep learning (CNN, BiLSTM/RNN)','Feature extraction','Generative AI / LLM APIs','AI-assisted development']],
      ['Databases',['MySQL','Microsoft SQL Server','Oracle Database & PL/SQL']],
      ['Tools & Foundations',['Git','GitHub','Postman','Linux','Windows','Object-Oriented Programming']]
    ],
    experienceLabel: '03 / THE JOURNEY', experienceTitle: 'From requirements to the real world.',
    experience: [
      {date:'2025 — Present',role:'Freelance Backend Developer',company:'Independent · Remote',description:'Deliver backend and full-stack projects for remote clients, managing the full lifecycle from requirements to live deployment. Design custom backend systems and REST APIs for web and mobile applications.'},
      {date:'Sep 2025 — Present',role:'Web Developer & IT Support',company:'Al-Adham Private School · Hama',description:'Own and maintain the school’s official website and internal IT systems, from feature development to infrastructure. Support administrative and academic workflows and occasionally teach computer skills and AI fundamentals.',url:'https://aladhamedu.com'},
      {date:'Sep 2025 — Aug 2026',role:'Technical Instructor (Teaching Assistant)',company:'Al-Wataniya Private University · Hama',description:'Delivered practical instruction in AI, NLP, MATLAB, advanced Microsoft Office, and PL/SQL. Mentored students through hands-on projects and technical problem-solving.'},
      {date:'Aug 2024 — Jan 2025',role:'Backend Developer Intern',company:'Extend for Digital Solutions & Marketing · Hama',description:'Developed Laravel and CodeIgniter backend modules and debugged features for Motobox, a local food delivery platform. Built and optimized REST APIs and MySQL operations alongside senior developers.'}
    ],
    projectsLabel:'04 / SELECTED WORK', projectsTitle:'Practical problems. Purposeful systems.', projectsIntro:'A selection of backend platforms and applied AI work.',
    featured:'FEATURED / GRADUATION PROJECT', projectLabel:'WEB PLATFORM', screenshot:'ADD SCREENSHOT HERE', livePlaceholder:'ADD LIVE LINK', githubPlaceholder:'ADD GITHUB LINK', live:'Live project', code:'Source code',
    projects:[
      {title:'Deepfake Detection Website',description:'A full-stack platform for detecting manipulated images, video, and audio. FastAPI serves deep learning inference to a Laravel frontend, with authenticated user and admin dashboards and confidence-score visualizations. Findings published in Advances in Applied Sciences, January 2026.',alt:'Screenshot of the Deepfake Detection Website'},
      {title:'Phone Marketplace Platform',description:'One backend for a web platform and Flutter companion app. Natural-language search powered by generative AI, wallet top-ups, device comparison, listings, and an admin dashboard. REST API documentation prepared for the mobile team and validated with Postman.',alt:'Screenshot of the Phone Marketplace Platform'},
      {title:'APS School Management System',description:'Student records, scheduling, lessons, and administrative reporting in one school platform. A scalable REST API architecture supports role-based dashboards for academic and administrative workflows.',alt:'Screenshot of the APS School Management System'}
    ],
    publicationLabel:'05 / BEYOND THE CODE', publicationTitle:'Engineering, backed by research.', paperMeta:'PEER-REVIEWED PUBLICATION · JAN 2026', paperTitle:'Audio Deepfake Detection Using a Hybrid Model of CNN and BiLSTM', paperAuthors:'Samar Al-Halabi & Adnan Kafri', paperJournal:'Advances in Applied Sciences · Volume 11, Issue 1', readPaper:'Read the publication',
    educationLabel:'06 / FOUNDATIONS',educationTitle:'A commitment to learning.',educationDate:'October 2020 — August 2025',degree:'Bachelor of Computer Engineering',university:'Al-Wataniya Private University · Hama, Syria',distinction:'Graduated with distinction',
    achievements:[['3.47/4.0','Cumulative GPA'],['Top 3','Ranked among the top Computer Engineering students for 5 consecutive years.'],['CPC','Honorable Mention — Syrian Private Universities Collegiate Programming Contest.']],
    contactLabel:'07 / WHAT’S NEXT',contactTitle:'Let’s build something that works.',contactIntro:'Have a platform in mind or a backend role to fill? I’m available for remote freelance work and backend / Laravel opportunities.',formName:'Your name',formEmail:'Email address',formMessage:'Tell me about your project or role',formHint:'This form opens your email app with a prepared draft. You can review it before sending.',send:'Prepare email',formStatus:'Your email draft is ready in your email app. If it didn’t open, email adnanzz444@gmail.com directly.',subject:'Portfolio inquiry from ',emailName:'Name',emailAddress:'Email',footer:'Backend development. With purpose.',backTop:'Back to top',lightMode:'Switch to light mode',darkMode:'Switch to dark mode',openMenu:'Open navigation',closeMenu:'Close navigation',navLabel:'Main navigation'
  },
  ar: {
    metaTitle:'عدنان كفري — مطوّر Laravel وأنظمة الذكاء الاصطناعي',metaDescription:'عدنان كفري، مهندس حاسوب ومطوّر خلفيات من حماة، سوريا. متخصص في Laravel وواجهات API وقواعد البيانات وتكامل الذكاء الاصطناعي. متاح للعمل الحر عن بُعد.',
    skip:'انتقل إلى المحتوى',name:'عدنان كفري',intro:'مهندس حاسوب · مطوّر الأنظمة الخلفية',title:'مطوّر ويب خلفي (Laravel) | أنظمة متكاملة مع الذكاء الاصطناعي',statement:'أنظمة متقنة.\nوإمكانات أذكى.',value:'أطوّر منصات Laravel وواجهات API موثوقة، وأوظّف الذكاء الاصطناعي في تطبيقات ويب عملية.',available:'متاح للعمل الحر',viewProjects:'استعرض المشاريع',contactMe:'تواصل معي',location:'حماة، سوريا',portraitLabel:'الهندسة تلتقي بالذكاء الاصطناعي.',portraitNote:'حلول تُبنى على أسس متينة.',portraitSub:'Laravel · واجهات API · ذكاء اصطناعي',portraitAlt:'عدنان كفري يتحدث مستخدماً الميكروفون',aiSystems:'أنظمة متكاملة مع الذكاء الاصطناعي',
    nav:[['about','نبذة عنّي'],['skills','المهارات'],['experience','الخبرات'],['projects','المشاريع'],['contact','لنتحدث ↗']],
    aboutLabel:'01 / نبذة عنّي',aboutTitle:'المهندس وراء الشيفرة.',profile:'أنا مهندس حاسوب متخصص في تطوير الأنظمة الخلفية، بخبرة عملية تزيد على ثلاث سنوات في Laravel. أركز على تصميم واجهات REST API وقواعد البيانات العلائقية ونشر التطبيقات في بيئات الإنتاج، مع دمج نماذج التعلم العميق وميزات النماذج اللغوية في منصات الويب. تخرجت بامتياز، وأجمع بين التطوير العملي والبحث العلمي من خلال بحث منشور حول كشف التزييف العميق.',
    facts:[['الموقع','حماة، سوريا · أعمل عن بُعد'],['اللغات','العربية — اللغة الأم · الإنجليزية — C1'],['التعليم','بكالوريوس هندسة الحاسوب · تخرج بامتياز']],
    skillsLabel:'02 / أدوات العمل',skillsTitle:'الأدوات المناسبة لأساس متين.',skills:[['تطوير الويب والأنظمة الخلفية',['Laravel','PHP','CodeIgniter','FastAPI (Python)','تصميم REST API','HTML','CSS','JavaScript','Bootstrap','TailwindCSS']],['الذكاء الاصطناعي وتعلم الآلة',['تدريب نماذج التعلم العميق (CNN, BiLSTM/RNN)','استخراج الميزات','تكامل واجهات الذكاء التوليدي والنماذج اللغوية','التطوير بمساعدة الذكاء الاصطناعي']],['قواعد البيانات',['MySQL','Microsoft SQL Server','Oracle Database & PL/SQL']],['الأدوات والأساسيات',['Git','GitHub','Postman','Linux','Windows','البرمجة كائنية التوجه']]],
    experienceLabel:'03 / المسيرة المهنية',experienceTitle:'من المتطلبات إلى التطبيق الفعلي.',experience:[
      {date:'2025 — حتى الآن',role:'مطوّر أنظمة خلفية مستقل',company:'عمل حر · عن بُعد',description:'تنفيذ مشاريع خلفية وتطبيقات ويب متكاملة لعملاء عن بُعد، وإدارة دورة المشروع من تحديد المتطلبات حتى النشر. تصميم أنظمة مخصصة وواجهات REST API لتطبيقات الويب والموبايل.'},
      {date:'سبتمبر 2025 — حتى الآن',role:'مطوّر ويب ودعم تقني',company:'مدرسة الأدهم الخاصة · حماة',description:'تطوير الموقع الرسمي للمدرسة وصيانته، وإدارة أنظمة تقنية المعلومات الداخلية والبنية التحتية. دعم الإجراءات الإدارية والأكاديمية، وتقديم تدريبات دورية في مهارات الحاسوب وأساسيات الذكاء الاصطناعي.',url:'https://aladhamedu.com'},
      {date:'سبتمبر 2025 — أغسطس 2026',role:'مدرّس عملي (مساعد تدريس)',company:'الجامعة الوطنية الخاصة · حماة',description:'تدريس الجوانب العملية للذكاء الاصطناعي ومعالجة اللغة الطبيعية، إلى جانب MATLAB وMicrosoft Office المتقدم وPL/SQL. إرشاد الطلاب في المشاريع التطبيقية وحل المشكلات التقنية.'},
      {date:'أغسطس 2024 — يناير 2025',role:'متدرّب تطوير الأنظمة الخلفية',company:'Extend للحلول الرقمية والتسويق · حماة',description:'تطوير وصيانة وحدات خلفية باستخدام Laravel وCodeIgniter، ومعالجة الأخطاء في منصة توصيل الطعام المحلية Motobox. بناء وتحسين واجهات REST API وعمليات MySQL بالتعاون مع المطوّرين الأقدم.'}
    ],
    projectsLabel:'04 / أعمال مختارة',projectsTitle:'مشكلات واقعية. حلول هادفة.',projectsIntro:'مجموعة من منصات الويب وتطبيقات الذكاء الاصطناعي التي عملت عليها.',featured:'مشروع مميز / مشروع التخرج',projectLabel:'منصة ويب',screenshot:'أضف لقطة شاشة هنا',livePlaceholder:'أضف رابط المشروع',githubPlaceholder:'أضف رابط GITHUB',live:'عرض المشروع',code:'الشيفرة المصدرية',projects:[
      {title:'منصة كشف التزييف العميق',description:'منصة متكاملة لكشف التلاعب بالصور والفيديو والصوت. تخدم FastAPI نماذج التعلم العميق عبر واجهات REST متصلة بواجهة Laravel، مع تسجيل دخول ولوحات للمستخدمين والإدارة وعرض مرئي لدرجات الثقة. نُشرت النتائج في مجلة Advances in Applied Sciences في يناير 2026.',alt:'لقطة شاشة لمنصة كشف التزييف العميق'},
      {title:'منصة بيع وشراء الهواتف',description:'نظام خلفي موحد لمنصة ويب وتطبيق Flutter مرافق، مع بحث باللغة الطبيعية مدعوم بالذكاء الاصطناعي التوليدي. يشمل المحفظة وشحن الرصيد ومقارنة الأجهزة وإدارة الإعلانات ولوحة الإدارة، مع توثيق شامل لواجهات API لفريق الموبايل والتحقق منها باستخدام Postman.',alt:'لقطة شاشة لمنصة بيع وشراء الهواتف'},
      {title:'نظام APS لإدارة المدارس',description:'منصة تجمع سجلات الطلاب والجداول والدروس والتقارير الإدارية. تعتمد على بنية قابلة للتوسع وواجهات REST API، مع لوحات تحكم حسب الصلاحيات لدعم العمل الأكاديمي والإداري.',alt:'لقطة شاشة لنظام APS لإدارة المدارس'}
    ],publicationLabel:'05 / البحث العلمي',publicationTitle:'هندسة تستند إلى البحث.',paperMeta:'بحث علمي محكّم · يناير 2026',paperTitle:'كشف التزييف العميق الصوتي باستخدام نموذج هجين من CNN وBiLSTM',paperAuthors:'سمر الحلبي وعدنان كفري',paperJournal:'Advances in Applied Sciences · المجلد 11، العدد 1',readPaper:'اقرأ البحث',educationLabel:'06 / الأساس العلمي',educationTitle:'التزام مستمر بالتعلّم.',educationDate:'أكتوبر 2020 — أغسطس 2025',degree:'بكالوريوس هندسة الحاسوب',university:'الجامعة الوطنية الخاصة · حماة، سوريا',distinction:'تخرج بامتياز',achievements:[['3.47/4.0','المعدل التراكمي'],['أفضل 3','ضمن أفضل ثلاثة طلاب في هندسة الحاسوب لخمس سنوات متتالية.'],['CPC','تنويه شرفي — المسابقة البرمجية للجامعات السورية الخاصة.']],
    contactLabel:'07 / الخطوة التالية',contactTitle:'لنبنِ معاً حلولاً تُحدث فرقاً.',contactIntro:'لديك فكرة منصة أو فرصة عمل في تطوير الأنظمة الخلفية؟ أنا متاح للعمل الحر عن بُعد وفرص تطوير Laravel.',formName:'الاسم',formEmail:'البريد الإلكتروني',formMessage:'أخبرني عن مشروعك أو فرصة العمل',formHint:'يفتح النموذج تطبيق البريد بمسودة جاهزة، ويمكنك مراجعتها قبل الإرسال.',send:'جهّز رسالة البريد',formStatus:'مسودة رسالتك جاهزة في تطبيق البريد. إذا لم يُفتح، راسلني مباشرة على adnanzz444@gmail.com.',subject:'استفسار من موقع الأعمال — ',emailName:'الاسم',emailAddress:'البريد الإلكتروني',footer:'تطوير هادف للأنظمة الخلفية.',backTop:'إلى الأعلى',lightMode:'تفعيل الوضع الفاتح',darkMode:'تفعيل الوضع الداكن',openMenu:'فتح قائمة التنقل',closeMenu:'إغلاق قائمة التنقل',navLabel:'التنقل الرئيسي'
  }
};

/* Redesign interface copy. All original content above is preserved. */
window.PORTFOLIO.system = {
  email: 'adnanzz444@gmail.com', phone: '+963 952 749 458',
  github: 'https://github.com/AdnanKafri', linkedin: 'https://linkedin.com/in/adnan-kafri-75021131b',
  request: 'GET /api/adnan', stack: ['Laravel', 'REST APIs', 'FastAPI', 'MySQL'],
  citation: 'Al-Halabi, S., & Kafri, A. (2026). Audio Deepfake Detection Using a Hybrid Model of CNN and BiLSTM. Advances in Applied Sciences, 11(1). https://doi.org/10.11648/j.aas.20261101.11',
  en: {
    concept: 'The backend, made visible.', edition: 'PERSONAL PORTFOLIO / ADNAN KAFRI', systemLabel: 'A person behind every system.', explore: 'Follow the connections',
    consoleLabel: 'PROFILE ENDPOINT', consoleNote: 'Interactive profile · local demonstration', run: 'Run again', running: 'Running request…', ready: 'Profile response ready.',
    aboutWord: 'Human.', skillsWord: 'Toolkit.', experienceWord: 'Trajectory.', projectsWord: 'Systems.', publicationWord: 'Evidence.', educationWord: 'Foundations.', contactWord: 'Connect.',
    current: 'CURRENTLY WORKING ON', currentBody: 'Freelance backend & full-stack projects. Website development and internal IT systems at Al-Adham Private School.',
    yearsLabel: 'years of hands-on Laravel development', rankLabel: 'consecutive years among the Top 3', stackLabel: 'TOOLS IN THE LOOP',
    architecture: 'Inside the system', architectureNote: 'Simplified architecture · based on project functionality', expand: 'Explore system', collapse: 'Close system',
    user: 'User', model: 'Deep learning', score: 'Confidence score', dashboard: 'Dashboard', web: 'Web platform', flutter: 'Flutter app', search: 'Generative AI search', searchLines: ['Generative AI', 'search'], school: 'School workflows', roles: 'Role-based dashboards',
    deepFlow: 'User to Laravel to FastAPI to deep learning (EfficientNet-B4 / BiLSTM and MFCC), then confidence score and dashboard.', phoneFlow: 'Web and Flutter clients connect to the Laravel API, which connects to MySQL and generative AI search.', schoolFlow: 'School workflows connect through a Laravel REST API and MySQL to role-based dashboards.',
    citationLabel: 'RESEARCH / JOURNAL ARTICLE', copyCitation: 'Copy citation', copied: 'Copied to clipboard.', copyFailed: 'Automatic copy unavailable. Select and copy the text below.',
    palette: 'Command menu', palettePlaceholder: 'Find a section or action…', paletteHelp: '↑ ↓ navigate · Enter select · Esc close', noResults: 'No matching commands.', close: 'Close', jump: 'Jump to', switchLanguage: 'Switch to Arabic', toggleTheme: 'Toggle theme', copyEmail: 'Copy email', openGithub: 'Open GitHub', commands: 'Open command menu',
    motionPause: 'Pause motion', motionResume: 'Resume motion', emailLabel: 'Email', phoneLabel: 'Phone', footerSystem: 'Thought → system → experience', noscript: 'The full portfolio is readable without JavaScript. Enable it for language switching and interactive features.'
  },
  ar: {
    concept: 'ما وراء الواجهة، أمامك.', edition: 'ملف الأعمال الشخصي / عدنان كفري', systemLabel: 'وراء كل نظام، إنسان.', explore: 'تتبّع الروابط',
    consoleLabel: 'واجهة الملف الشخصي', consoleNote: 'ملف تفاعلي · عرض محلي توضيحي', run: 'تشغيل مجدداً', running: 'جارٍ تشغيل الطلب…', ready: 'استجابة الملف الشخصي جاهزة.',
    aboutWord: 'الإنسان.', skillsWord: 'الأدوات.', experienceWord: 'المسيرة.', projectsWord: 'الأنظمة.', publicationWord: 'البحث.', educationWord: 'الأساس.', contactWord: 'التواصل.',
    current: 'أعمل حالياً على', currentBody: 'مشاريع مستقلة لتطوير الأنظمة الخلفية وتطبيقات الويب المتكاملة، وتطوير موقع مدرسة الأدهم الخاصة وأنظمتها التقنية الداخلية.',
    yearsLabel: 'سنوات من الخبرة العملية في Laravel', rankLabel: 'سنوات متتالية ضمن أفضل ثلاثة طلاب', stackLabel: 'أدوات تتكامل معاً',
    architecture: 'داخل النظام', architectureNote: 'مخطط مبسّط يستند إلى وظائف المشروع', expand: 'استكشف النظام', collapse: 'إغلاق التفاصيل',
    user: 'المستخدم', model: 'التعلم العميق', score: 'درجة الثقة', dashboard: 'لوحة التحكم', web: 'منصة الويب', flutter: 'تطبيق Flutter', search: 'بحث بالذكاء التوليدي', searchLines: ['بحث بالذكاء', 'التوليدي'], school: 'العمليات المدرسية', roles: 'لوحات حسب الصلاحيات',
    deepFlow: 'من المستخدم إلى Laravel ثم FastAPI ونماذج التعلم العميق (EfficientNet-B4 وBiLSTM وMFCC)، وصولاً إلى درجة الثقة ولوحة التحكم.', phoneFlow: 'تتصل منصة الويب وتطبيق Flutter بواجهة Laravel API، التي تتكامل مع MySQL والبحث بالذكاء الاصطناعي التوليدي.', schoolFlow: 'تتصل العمليات المدرسية عبر Laravel REST API وMySQL بلوحات تحكم حسب الصلاحيات.',
    citationLabel: 'بحث علمي / مقال محكّم', copyCitation: 'نسخ الاستشهاد', copied: 'تم النسخ إلى الحافظة.', copyFailed: 'تعذّر النسخ التلقائي. حدّد النص أدناه وانسخه.',
    palette: 'قائمة الأوامر', palettePlaceholder: 'ابحث عن قسم أو إجراء…', paletteHelp: '↑ ↓ للتنقل · Enter للاختيار · Esc للإغلاق', noResults: 'لا توجد أوامر مطابقة.', close: 'إغلاق', jump: 'انتقل إلى', switchLanguage: 'Switch to English', toggleTheme: 'تبديل المظهر', copyEmail: 'نسخ البريد الإلكتروني', openGithub: 'فتح GitHub', commands: 'فتح قائمة الأوامر',
    motionPause: 'إيقاف الحركة', motionResume: 'استئناف الحركة', emailLabel: 'البريد الإلكتروني', phoneLabel: 'الهاتف', footerSystem: 'فكرة ← نظام ← تجربة', noscript: 'يمكنك قراءة ملف الأعمال كاملاً دون JavaScript. فعّله لتبديل اللغة واستخدام الميزات التفاعلية.'
  }
};
