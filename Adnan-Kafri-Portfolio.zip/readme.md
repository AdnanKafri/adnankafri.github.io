# Adnan Kafri — portfolio

Upload-ready static user site for **https://adnankafri.github.io/**. English lives at `/`; Arabic at `/ar/`. Both pages contain the full text in their HTML. GitHub Pages does not run a build.

## Upload this release

1. Extract `adnan-kafri-portfolio.zip`.
2. Open [AdnanKafri/adnankafri.github.io](https://github.com/AdnanKafri/adnankafri.github.io). Copy the extracted **contents** into the repository root: `index.html` must sit beside `.nojekyll`, `ar/`, `assets/`, `css/` and `js/`, not inside another folder. Include the hidden `.nojekyll` file. Do not upload the ZIP, `node_modules`, or old backup archives.
3. Commit and push to `main`. With an existing checkout, review `git status`, then use `git add -A`, `git commit -m "Prepare bilingual portfolio for launch"`, and `git push origin main`. Nothing has been pushed by this delivery.
4. In **Settings → Pages → Build and deployment**, select **Deploy from a branch**, **main**, **/(root)**, then Save. Check the Pages deployment in Actions. These are GitHub's [branch publishing settings](https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site).
5. Visit `https://adnankafri.github.io/`, `/ar/`, `/sitemap.xml`, `/robots.txt`, and a nonexistent path. Check English/Arabic, both themes, the mobile menu and contact actions. A nested missing path should return the bilingual 404 page.

No CNAME file is included. No credentials, analytics, trackers, fake verification tokens, or message-sending backend are included.

## Edit content and regenerate

Use Node.js 22 or newer. From this folder:

```sh
npm ci
npm run build
npm run serve
```

Preview at `http://127.0.0.1:8080/` and `http://127.0.0.1:8080/ar/`. The preview server deliberately enforces case-sensitive paths, including on Windows. Stop it with Ctrl+C. Do not use `file://` to assess deployment behavior.

Edit English/Arabic copy, skills, experience and projects in `js/content.js`. Keep facts aligned with the CV. Each language has its own SEO title, description, services and coverage copy. Section labels run 01–07. Shared contacts and the console data are in `system`. The photo is `assets/adnan.webp`; the source logo is `assets/ak-logo.png`.

`tools/template.html` holds the shared semantic layout. `js/main.js` renders the same content during generation and enhances the pages in the browser. `tools/build.mjs` emits `index.html`, `ar/index.html`, `404.html`, `sitemap.xml`, `robots.txt` and `site.webmanifest`. Commit those generated files after every copy/layout/domain change; editing only `content.js` would leave search engines reading stale HTML. Keep asset filenames lowercase ASCII without spaces.

Project configuration uses optional fields:

```js
{
  image: null,
  liveUrl: null,
  repoUrl: null,
  stack: ["Laravel", "MySQL"]
}
```

Set a field only when you have its real asset or URL. Image paths are relative to the project root, such as `assets/deepfake.webp`; runtime and generator resolve them for both languages. Supply localized `alt` text under the matching English/Arabic project and use a 1200×750 image, or update its declared dimensions in the renderer. Empty fields create no links, labels or image frames. The existing architecture diagrams remain. Project screenshots and repository/live links are optional and currently omitted.

The email button prepares a `mailto:` draft; WhatsApp opens `https://wa.me/963952749458?text=...`. Both validate name, email and message, encode Unicode and line breaks, and require the visitor to send the message. No message is submitted to a server. A draft is temporarily stored in sessionStorage only when switching languages, then consumed on the destination page. Theme, language preference and motion preference use localStorage; there is no automatic language redirect.

## Change the domain later

`SITE_URL` in `site.config.json` is the only configurable site address. The generated URL fields are derived from it; do not edit them individually. After buying your domain, run the following with its real HTTPS origin:

```sh
node tools/set-domain.mjs https://YOUR-PURCHASED-DOMAIN
```

This updates config and regenerates canonical URLs, Open Graph URLs/images, hreflang, JSON-LD, sitemap and robots in one command. It rejects paths, queries and non-HTTPS addresses. It does not create CNAME or change DNS.

For an apex domain with `www` as an alias:

1. Verify the purchased domain in your GitHub account's Pages settings if available, following GitHub's [domain verification guidance](https://docs.github.com/en/pages/configuring-a-custom-domain-for-your-github-pages-site/verifying-your-custom-domain-for-github-pages).
2. Set the purchased apex name in this repository's **Settings → Pages → Custom domain**. Branch publishing creates the required CNAME commit; pull it into your checkout before your next push.
3. At the DNS provider, create four apex (`@`) A records: `185.199.108.153`, `185.199.109.153`, `185.199.110.153`, `185.199.111.153`. Set `www` CNAME to `adnankafri.github.io` — no protocol or path. Remove conflicting records for those names. GitHub documents these values and redirects in [Managing a custom domain](https://docs.github.com/en/pages/configuring-a-custom-domain-for-your-github-pages-site/managing-a-custom-domain-for-your-github-pages-site).
4. Wait for GitHub's DNS check/certificate, then enable **Enforce HTTPS**. Check apex, www, `/ar/`, images and the 404 page. HTTPS provisioning can take time; see [GitHub HTTPS guidance](https://docs.github.com/en/pages/getting-started-with-github-pages/securing-your-github-pages-site-with-https).
5. Run the domain script, commit the changed files, and deploy. Confirm the new domain's canonical, sitemap and robots URLs. Add and verify the new property in Search Console/Bing, submit its sitemap, inspect both pages and request indexing. Keep the GitHub Pages custom-domain redirect active for the old address.

## Search indexing and sharing

After the site is live:

- In [Google Search Console](https://search.google.com/search-console), add the exact URL-prefix property `https://adnankafri.github.io/`. Use the real HTML verification file supplied by Google (upload unchanged to the root), or add its actual meta tag to `tools/template.html` and regenerate. For a later domain property, verify the real DNS TXT record instead.
- Submit `https://adnankafri.github.io/sitemap.xml` in **Sitemaps**. Use URL Inspection on both `/` and `/ar/`, test the live URLs and request indexing. Monitor Page indexing. Google describes [URL inspection and indexing requests](https://support.google.com/webmasters/answer/12482179).
- In [Bing Webmaster Tools](https://www.bing.com/webmasters/), import the verified Google property or verify independently. Submit the same sitemap through **Sitemaps** and inspect both URLs; see [Bing sitemap instructions](https://www.bing.com/webmasters/help/sitemaps-3b5cf6ed).
- Test the public URL in [Facebook Sharing Debugger](https://developers.facebook.com/tools/debug/) and [LinkedIn Post Inspector](https://www.linkedin.com/post-inspector/). Ask them to refresh cached previews after changes to the logo or `assets/og-image.png`.
- Test structured data with [Schema.org Validator](https://validator.schema.org/) and [Google Rich Results Test](https://search.google.com/test/rich-results). Person, WebSite, ProfilePage and ScholarlyArticle are supplied. Schema validity does not guarantee a rich result or search ranking. No fake reviews, ratings or offices are declared.

Reciprocal `en`, `ar`, and `x-default` links are emitted in both pages and the sitemap, following [Google's localized-page guidance](https://developers.google.com/search/docs/specialty/international/localized-versions). Coverage copy truthfully states Hama as the base, with clients across Syria including Homs/Damascus and online.

## Design and maintenance

The palette is defined at the top of `css/styles.css`: graphite/champagne gold/silver for dark mode, limestone/bronze/warm gray for light. All sections, diagrams, cursor, progress, focus, selection, errors and contact controls use those tokens. Self-hosted Syne, Inter, IBM Plex Mono and Cairo have `font-display: swap`; their licenses are in `assets/fonts/`. Font subsets/weights are deduplicated. The unused Tailwind runtime was removed; custom CSS already owns this design.

GSAP 3.14.2, ScrollTrigger 3.14.2 and Lenis 1.3.26 use versioned CDN URLs, `defer`, SHA-384 integrity and anonymous CORS. If changing those versions in the template, run `node tools/update-cdn-integrity.mjs` followed by `npm run build`. Font/icon files are already generated and require no deployment tools. To regenerate logo-derived icon/OG assets, install Python/Pillow and run `python tools/create-icons.py`.

The single Application Stack contains four semantic lists with hidden accessibility clones for the loop. Each row pauses on hover, focus or its touch-friendly pause button; reduced-motion mode displays the original list as wrapped items and hides clones. The shorter rows fill their viewport so the loop never runs into an empty tail. Global pause also stops decorative motion. Arabic mirrors layout and movement while isolating Latin technical terms.

The release report is `launch-report.md`. Reproducible audit scripts and JSON evidence are in `qa/`; screenshots and full Lighthouse artifacts are retained in the working folder, outside the ZIP. Browser audit dependencies can be installed separately with `npm install --prefix "%TEMP%/adnan-portfolio-qa" playwright axe-core jsdom html-validate lighthouse` (Command Prompt syntax). The included scripts use Chrome on Windows; adjust `executablePath` for another environment. Run the preview server before browser scripts. `node qa/static-audit.mjs` verifies paths, semantic lists, contrast tokens and reversible domain migration; `node qa/contact-regression.cjs` checks email draft construction without launching an email client. Browser audits intercept WhatsApp navigation and send no messages.
