from pathlib import Path
import zipfile,hashlib,json
root=Path(__file__).resolve().parents[1]
files=[root/name for name in ['index.html','404.html','.nojekyll','.gitignore','robots.txt','sitemap.xml','site.webmanifest','site.config.json','package.json','package-lock.json','readme.md','launch-report.md']]
for folder in ['ar','assets','css','js','tools']:
    files.extend(p for p in (root/folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts)
files.extend(p for p in (root/'qa').iterdir() if p.is_file() and p.suffix in ['.json','.mjs','.cjs'] and not p.name.startswith('inspect-'))
archive=root/'adnan-kafri-portfolio.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as out:
    for file in sorted(files):
        name=file.relative_to(root).as_posix()
        assert name==name.lower() and name.isascii() and ' ' not in name,name
        out.write(file,name)
with zipfile.ZipFile(archive) as check:
    assert check.testzip() is None
    assert 'index.html' in check.namelist() and 'ar/index.html' in check.namelist() and '.nojekyll' in check.namelist()
    assert 'CNAME' not in check.namelist()
print(json.dumps({'archive':str(archive),'files':len(files),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()},indent=2))
