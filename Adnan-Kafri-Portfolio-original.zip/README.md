# Adnan Kafri — personal portfolio

A buildless, bilingual portfolio using HTML5, Tailwind CSS CDN, local CSS, and vanilla JavaScript. Open `index.html` directly, or run `python -m http.server 8080` from this folder and visit http://localhost:8080.

## Files

- `index.html`: semantic page structure, SEO and Person schema.
- `css/styles.css`: responsive layout, dark/light palettes, RTL and reduced-motion support. The layout also works if the Tailwind CDN is unavailable.
- `js/content.js`: all English and Arabic content, project screenshot paths, and project links.
- `js/main.js`: language/theme persistence, navigation, rendering, and email draft form.
- `assets/adnan.webp`: optimized version of the supplied photo.
- `assets/favicon.svg`: replaceable initials favicon.

## Deploy

**GitHub Pages:** Put `index.html`, `css/`, `js/`, and `assets/` in the root of a repository. In Settings → Pages, choose Deploy from a branch, select the branch and `/ (root)`, then Save. Use the URL GitHub provides.

**Netlify:** Drag a folder containing those same files into Netlify's manual deploy area. No build command is needed. If connecting a repository, leave the build command empty and set the publish directory to `.`.

Do not upload the original full-size photograph; only the optimized asset is needed. No credentials or backend services are required.

## Before sharing publicly

1. In `js/content.js`, replace the three projects' `image`, `live`, and `github` null values with real image paths and URLs. Until then, explicit placeholders appear; there are no pretend links or project screenshots.
2. The existing workspace photo is included. Replace `assets/adnan.webp` if you prefer another portrait, and update its bilingual alt text in `content.js`.
3. Optionally replace `assets/favicon.svg` with a personal favicon.
4. After choosing the public domain, use absolute URLs for `og:image`, add an `og:url` meta tag and canonical link in `index.html`, and optionally add your site URL to the Person schema. Use a dedicated 1200×630 sharing image for the best social previews.
5. The form prepares a `mailto:` draft, not a server submission. Visitors need a configured email application and must send the draft themselves. Direct email, phone, GitHub, and LinkedIn links are also provided. To use Formspree later, replace the submit handler with your verified Formspree endpoint and adjust the bilingual hint/status copy.

English and dark mode are the first-visit defaults. Language and theme selections persist when localStorage is available. Google Fonts and the optional Tailwind CDN need internet access; local styles and fallback fonts keep the site readable offline. Tailwind's browser CDN is included as requested; for a strict CSP or a completely self-hosted site, replace it with a locally compiled stylesheet.

Content follows the supplied brief and CV. No invented clients, project results, or testimonials are included.
