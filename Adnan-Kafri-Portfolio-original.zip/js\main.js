'use strict';
(() => {
  const data = window.PORTFOLIO;
  const root = document.documentElement;
  const $ = (selector) => document.querySelector(selector);
  const read = (key) => { try { return localStorage.getItem(key); } catch { return null; } };
  const save = (key, value) => { try { localStorage.setItem(key, value); } catch { /* Private browsing still works. */ } };
  let language = read('ak-language') === 'ar' ? 'ar' : 'en';
  const escape = (value) => String(value).replace(/[&<>"']/g, (c) => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const safeURL = (value) => { if (!value) return null; try { const url = new URL(value, location.href); return ['http:', 'https:', 'file:'].includes(url.protocol) ? escape(value) : null; } catch { return null; } };
  const external = 'target="_blank" rel="noopener noreferrer"';
  const chips = (values) => `<div class="chips">${values.map(v => `<span class="chip" dir="auto">${escape(v)}</span>`).join('')}</div>`;
  function themeLabel() {
    const light = root.dataset.theme === 'light';
    $('#theme').textContent = light ? '☾' : '☼';
    $('#theme').setAttribute('aria-label', data[language][light ? 'darkMode' : 'lightMode']);
    $('meta[name="theme-color"]').content = light ? '#f5f6f1' : '#101413';
  }
  function closeMenu() {
    $('#navigation').classList.remove('open');
    $('#menu').setAttribute('aria-expanded','false');
    $('#menu').setAttribute('aria-label', data[language].openMenu);
  }
  function render() {
    const t = data[language];
    root.lang = language;
    root.dir = language === 'ar' ? 'rtl' : 'ltr';
    document.title = t.metaTitle;
    $('meta[name="description"]').content = t.metaDescription;
    $('meta[property="og:title"]').content = t.metaTitle;
    $('meta[property="og:description"]').content = t.metaDescription;
    $('meta[property="og:locale"]').content = language === 'ar' ? 'ar_SY' : 'en_US';
    document.querySelectorAll('[data-t]').forEach(el => { el.textContent = t[el.dataset.t]; });
    const statement = t.statement.split('\n');
    $('.hero-statement').innerHTML = `${escape(statement[0])}<br><em>${escape(statement[1])}</em>`;
    $('#portrait').alt = t.portraitAlt;
    $('#language').textContent = language === 'en' ? 'العربية' : 'English';
    $('#language').lang = language === 'en' ? 'ar' : 'en';
    $('#language').setAttribute('aria-label', language === 'en' ? 'التبديل إلى العربية' : 'Switch to English');
    $('#navigation').setAttribute('aria-label', t.navLabel);
    $('#navigation').innerHTML = t.nav.map(([id,title]) => `<a href="#${id}">${escape(title)}</a>`).join('');
    $('#facts').innerHTML = t.facts.map(([label,value]) => `<div><dt>${escape(label)}</dt><dd>${escape(value)}</dd></div>`).join('');
    $('#skill-grid').innerHTML = t.skills.map(([title,items], i) => `<article class="skill-card"><h3><span class="skill-number">0${i+1}</span>${escape(title)}</h3>${chips(items)}</article>`).join('');
    $('#timeline').innerHTML = t.experience.map(item => `<article class="timeline-row"><p class="timeline-date">${escape(item.date)}</p><div class="timeline-body"><h3>${escape(item.role)}</h3><p class="company">${item.url ? `<a href="${safeURL(item.url)}" ${external}>${escape(item.company)} ↗</a>` : escape(item.company)}</p><p>${escape(item.description)}</p></div></article>`).join('');
    $('#project-grid').innerHTML = t.projects.map((project, i) => {
      const config = data.projects[i];
      const projectLink = (url, label, placeholder) => safeURL(url) ? `<a class="text-link" href="${safeURL(url)}" ${external}>${escape(label)} ↗</a>` : `<span class="placeholder-link">${escape(placeholder)} ↗</span>`;
      return `<article class="project-card ${i===0?'featured':''}"><div class="project-media">${safeURL(config.image) ? `<img src="${safeURL(config.image)}" alt="${escape(project.alt)}" loading="lazy" width="700" height="440">` : `<span class="media-symbol" aria-hidden="true">${['[ ◉ ]','{ ↔ }','[ ≡ ]'][i]}</span><span class="media-placeholder">${escape(t.screenshot)}</span>`}</div><div class="project-body"><div class="eyebrow">${escape(i===0?t.featured:t.projectLabel)}</div><h3>${escape(project.title)}</h3><p>${escape(project.description)}</p>${chips(config.stack)}<div class="project-links">${projectLink(config.live,t.live,t.livePlaceholder)}${projectLink(config.github,t.code,t.githubPlaceholder)}</div></div></article>`;
    }).join('');
    $('#achievements').innerHTML = t.achievements.map(([title,body]) => `<div class="achievement"><strong dir="auto">${escape(title)}</strong><span>${escape(body)}</span></div>`).join('');
    $('#form-status').textContent = '';
    $('#year').textContent = new Date().getFullYear();
    closeMenu(); themeLabel();
  }
  $('#language').addEventListener('click', () => { language = language === 'en' ? 'ar' : 'en'; save('ak-language',language); render(); });
  $('#theme').addEventListener('click', () => { root.dataset.theme = root.dataset.theme === 'dark' ? 'light' : 'dark'; save('ak-theme',root.dataset.theme); themeLabel(); });
  $('#menu').addEventListener('click', () => { const open = $('#navigation').classList.toggle('open'); $('#menu').setAttribute('aria-expanded',String(open)); $('#menu').setAttribute('aria-label',data[language][open?'closeMenu':'openMenu']); });
  $('#navigation').addEventListener('click', (event) => { if (event.target.closest('a')) closeMenu(); });
  document.addEventListener('keydown', (event) => { if(event.key === 'Escape' && $('#navigation').classList.contains('open')) {closeMenu(); $('#menu').focus();} });
  document.addEventListener('click', (event) => { if (!event.target.closest('.header')) closeMenu(); });
  $('#contact-form').addEventListener('submit', (event) => {
    event.preventDefault();
    const form = event.currentTarget;
    if (!form.reportValidity()) return;
    const values = new FormData(form), t = data[language];
    const name = String(values.get('name')).trim(), email = String(values.get('email')).trim(), message = String(values.get('message')).trim();
    if (!name || !message) { (name ? form.elements.message : form.elements.name).focus(); return; }
    const subject = encodeURIComponent(t.subject + name);
    const body = encodeURIComponent(`${t.emailName}: ${name}\n${t.emailAddress}: ${email}\n\n${message}`);
    window.location.href = `mailto:adnanzz444@gmail.com?subject=${subject}&body=${body}`;
    $('#form-status').textContent = t.formStatus;
  });
  render();
  if ('IntersectionObserver' in window && !window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
    const observer = new IntersectionObserver(entries => entries.forEach(entry => { if(entry.isIntersecting){entry.target.classList.add('animate-in'); observer.unobserve(entry.target);} }), {threshold:0.08});
    document.querySelectorAll('.reveal').forEach(section => observer.observe(section));
  }
})();
